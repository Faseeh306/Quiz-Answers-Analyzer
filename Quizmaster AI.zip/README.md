# QuizMaster AI

A GitHub-ready, clean-room implementation of the shared PartyRock quiz workflow. It generates multiple-choice quizzes from a subject, difficulty, and question count; then grades a learner's answers with optional negative marking and explanations.

This repository does **not** contain PartyRock's proprietary source code. It recreates the public-facing behavior as an independent Node.js application.

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.
3. Run `npm install`.
4. Run `npm start` and visit `http://localhost:3000`.

The key stays server-side. Do not add it to frontend files or commit `.env`.

## Deploy

This is a conventional Node web service. On Render, Railway, Fly.io, or similar:

- Build command: `npm install`
- Start command: `npm start`
- Environment variable: `OPENAI_API_KEY`
- Optional environment variable: `OPENAI_MODEL` (defaults to `gpt-5-mini`)

`render.yaml` provides a one-click Render blueprint. A production `Dockerfile` is also included for any Docker-capable host. For Vercel, deploy it as a Node server through a compatible adapter or use a host that supports persistent Express processes directly.

## API endpoints

- `POST /api/quiz` — accepts `subject`, `difficulty`, and `count`; returns a structured quiz.
- `POST /api/evaluate` — accepts the generated quiz, learner submission, and `negativeMarking`; returns Markdown evaluation.

The backend uses the official OpenAI JavaScript SDK and Responses API, keeping API credentials off the browser.
