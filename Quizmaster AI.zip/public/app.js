const $ = (selector) => document.querySelector(selector);
let currentQuiz = null;

$("#count").addEventListener("input", (event) => {
  $("#count-output").value = event.target.value;
  $("#count-output").textContent = event.target.value;
});

function setStatus(message, isError = false) {
  const status = $("#status");
  status.textContent = message;
  status.classList.toggle("error", isError);
}

async function request(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}

$("#generate").addEventListener("click", async () => {
  const button = $("#generate");
  button.disabled = true;
  setStatus("Designing your quiz…");
  try {
    const { quiz } = await request("/api/quiz", {
      subject: $("#subject").value,
      difficulty: $("#difficulty").value,
      count: $("#count").value
    });
    currentQuiz = quiz;
    $("#quiz-title").textContent = quiz.title || "Your quiz";
    $("#questions").innerHTML = quiz.questions.map((item, index) => `
      <article class="question">
        <h3>${index + 1}. ${escapeHtml(item.question)}</h3>
        <ol type="A">${item.options.map((option) => `<li>${escapeHtml(option)}</li>`).join("")}</ol>
      </article>`).join("");
    $("#quiz-panel").classList.remove("hidden");
    $("#submit-panel").classList.remove("hidden");
    $("#analysis-panel").classList.add("hidden");
    setStatus("Quiz ready. Good luck!");
    $("#quiz-panel").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    setStatus(error.message, true);
  } finally {
    button.disabled = false;
  }
});

$("#evaluate").addEventListener("click", async () => {
  const button = $("#evaluate");
  button.disabled = true;
  setStatus("Checking your answers…");
  try {
    const { evaluation } = await request("/api/evaluate", {
      quiz: currentQuiz,
      submission: $("#submission").value,
      negativeMarking: $("#negative").checked
    });
    // Model output is rendered as text, not HTML, so it cannot run scripts in the browser.
    $("#evaluation").textContent = evaluation;
    $("#analysis-panel").classList.remove("hidden");
    setStatus("Analysis ready.");
    $("#analysis-panel").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    setStatus(error.message, true);
  } finally {
    button.disabled = false;
  }
});

$("#new-quiz").addEventListener("click", () => {
  currentQuiz = null;
  ["#quiz-panel", "#submit-panel", "#analysis-panel"].forEach((id) => $(id).classList.add("hidden"));
  $("#submission").value = "";
  setStatus("Choose new preferences and generate another quiz.");
  $("#subject").focus();
});

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value;
  return div.innerHTML;
}
