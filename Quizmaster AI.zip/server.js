import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const quizSchema = {
  type: "object",
  additionalProperties: false,
  required: ["title", "questions"],
  properties: {
    title: { type: "string" },
    questions: {
      type: "array",
      minItems: 1,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["question", "options", "answer", "explanation"],
        properties: {
          question: { type: "string" },
          options: {
            type: "array",
            minItems: 4,
            maxItems: 4,
            items: { type: "string" }
          },
          answer: { type: "string", enum: ["A", "B", "C", "D"] },
          explanation: { type: "string" }
        }
      }
    }
  }
};

function openai() {
  if (!process.env.OPENAI_API_KEY) {
    const error = new Error("OPENAI_API_KEY is not configured. Add it to .env locally or your deployment environment.");
    error.status = 500;
    throw error;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw new Error("The model returned an invalid quiz response. Please try again.");
  }
}

app.post("/api/quiz", async (req, res, next) => {
  try {
    const { subject, difficulty, count } = req.body || {};
    const safeCount = Math.max(1, Math.min(20, Number(count) || 5));
    if (!subject || typeof subject !== "string" || subject.trim().length < 2) {
      return res.status(400).json({ error: "Enter a target subject with at least two characters." });
    }

    const response = await openai().responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      input: [
        {
          role: "developer",
          content: "You are a careful educational assessment designer. Create accurate, unambiguous multiple-choice questions. Do not include the answer key in question wording. Use plain text only."
        },
        {
          role: "user",
          content: `Create exactly ${safeCount} multiple-choice questions about: ${subject.trim()}\nDifficulty: ${difficulty || "Medium"}\nEach question needs exactly four options, one correct answer (A–D), and a concise teaching explanation.`
        }
      ],
      text: {
        format: {
          type: "json_schema",
          name: "quiz",
          strict: true,
          schema: quizSchema
        }
      }
    });

    const quiz = parseJson(response.output_text);
    res.json({ quiz });
  } catch (error) {
    next(error);
  }
});

app.post("/api/evaluate", async (req, res, next) => {
  try {
    const { quiz, submission, negativeMarking } = req.body || {};
    if (!quiz?.questions?.length) return res.status(400).json({ error: "Generate a quiz before submitting answers." });
    if (!submission || typeof submission !== "string") return res.status(400).json({ error: "Enter answers such as 1. A, 2. C, 3. B." });

    const response = await openai().responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      input: [
        {
          role: "developer",
          content: "You are a rigorous quiz evaluator. Reply in clear Markdown. First report the score. Then show a compact question-by-question table with submitted answer, correct answer, result, and explanation. Interpret common answer formats such as '1 A, 2:C'. Missing or invalid answers are incorrect. Do not invent answers."
        },
        {
          role: "user",
          content: `Quiz data:\n${JSON.stringify(quiz)}\n\nLearner submission:\n${submission}\n\nNegative marking: ${negativeMarking ? "enabled; subtract 0.25 for each incorrect answer" : "disabled; no deduction for incorrect answers"}`
        }
      ]
    });

    res.json({ evaluation: response.output_text });
  } catch (error) {
    next(error);
  }
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(error.status || 500).json({ error: error.message || "Something went wrong. Please try again." });
});

app.listen(port, () => console.log(`QuizMaster AI listening on http://localhost:${port}`));
